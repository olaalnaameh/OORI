This readme is for the purpose of allowing git to track this otherwise empty directory. This is to create database directory in our release package before writing any data.
